package com.stackroute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudSleuthDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudSleuthDemo1Application.class, args);
	}

}
