package com.stackroute.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/v1")
public class MyController {
	
	
	private RestTemplate restTemplate;

	@Autowired
	public MyController(RestTemplate restTemplate) {
		super();
		this.restTemplate = restTemplate;
	}
	
	@GetMapping("/microservice1")
	public String hello() {
		String response = restTemplate.getForObject("http://localhost:8081/api/v1/microservice2", String.class);
		return response;
	}

}
